Vexed Kelp Module V2

Load Vexed-Kelp-Module-V2.litematic in Litematica.
Read Vexed-Kelp-Module-V2-setup.md before the first start.
Keep the lever powered / STOP while building and stocking.
Full bonemeal boxes go into all four input chests.
Separate empty boxes go into the kelp-loader supply chest.
The dedicated return bank stores 864 empty bonemeal boxes for refilling.

Materials, V1 replacement checklist and the actual-engine validation record are included.

Schematic SHA-256: b25750fcc8e7e86fefb6ba9a0b9c3d436fffc7369f4ac1883c9c76e38d16f261
